QT       += core gui
QT += printsupport

greaterThan(QT_MAJOR_VERSION, 4): QT += widgets

CONFIG += c++17

# You can make your code fail to compile if it uses deprecated APIs.
# In order to do so, uncomment the following line.
#DEFINES += QT_DISABLE_DEPRECATED_BEFORE=0x060000    # disables all the APIs deprecated before Qt 6.0.0

SOURCES += src/mainwindow.cpp \
    src/generador.cpp \
    src/main.cpp \
    src/desafio.cpp \
    src/ejercicioDivisiones.cpp \
    src/ejercicioEcuacion.cpp \
    src/ejercicioFactorizar.cpp \
    src/ejercicioPorcentaje.cpp \
    src/ejercicioPotencia.cpp \
    src/ejercicioEcuacionGrafico.cpp \
    src/qcustomplot.cpp \
    src/ejercicioGeometria.cpp \
    src/ejercicioInecuaciones.cpp \
    src/ejercicioLogaritmos.cpp \
    src/ejercicioProbabilidad.cpp \
    src/ejercicioTrigonometria.cpp \
    src/ejercicioSistemaEcuaciones.cpp \
    src/productosnotables.cpp

HEADERS += include/mainwindow.h \
    include/ejercicios.h \
    include/qcustomplot.h

INCLUDEPATH += include


FORMS += src/mainwindow.ui

# Default rules for deployment.
qnx: target.path = /tmp/$${TARGET}/bin
else: unix:!android: target.path = /opt/$${TARGET}/bin
!isEmpty(target.path): INSTALLS += target

RESOURCES += \
    resources.qrc
