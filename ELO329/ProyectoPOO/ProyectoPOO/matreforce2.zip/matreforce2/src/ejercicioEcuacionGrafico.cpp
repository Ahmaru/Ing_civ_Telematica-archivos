#include "ejercicios.h"
#include "ui_mainwindow.h"
#include "qcustomplot.h"
#include <cmath>
#include <ctime>
#include <QVector>
#include <QPen>
#include <algorithm>


ejercicioEcuacionGrafico::ejercicioEcuacionGrafico(int tipo, Ui::MainWindow* ui) : m_ui(ui) {
    variedad = 1;
    // actualiza la semilla para la aleatoriedad
    std::srand(static_cast<unsigned int>(std::time(nullptr)));

    int a = (std::rand() % 19) - 9;
    int b = (std::rand() % 19) - 9;
    std::string signo;

    m_ui->widget_grafico->show(); // se muestra el widget que tiene el grafico
    

    QCustomPlot* customPlot = qobject_cast<QCustomPlot*>(m_ui->widget_grafico); // se usa CustomPlot para el grafico
    if (!customPlot) {

        customPlot = new QCustomPlot(m_ui->widget_grafico);
        customPlot->setGeometry(0, 0, 400, 400);
        customPlot->show();

    } else {

        customPlot->setFixedSize(400, 400);
    }
    

    m_ui->widget_grafico->setFixedSize(400, 400);
    

    if (a == 0) a = 1;
    
    if((2*a*b) < 0){
        soluciones->push_back("f(x) = " + std::to_string(a) + "x^2 " + std::to_string(2*a*b) + "x + " + std::to_string(b*b));
    }
    else{
        signo = "+";
        soluciones->push_back("f(x) = " + std::to_string(a) + "x^2 " + signo + " " + std::to_string(2*a*b) + "x + " + std::to_string(b*b));
    }
    


    enunciado = "¿Que función representa la siguiente parabola?";
    


    customPlot->clearGraphs();

    QVector<double> x, y;

    double x_min = -10.0;
    double x_max = 10.0;
    double step = 0.1;

    for (double i = x_min; i <= x_max; i += step) {
        x.push_back(i);

        double yi = a * i * i + b * i + (b*b);
        y.push_back(yi);
    }

    customPlot->addGraph();
    customPlot->graph(0)->setData(x, y);

    customPlot->graph(0)->setPen(QPen(Qt::blue, 2));

    customPlot->xAxis->setLabel("x");
    customPlot->yAxis->setLabel("y");


    customPlot->xAxis->setRange(-10, 10);


    double y_min = *std::min_element(y.begin(), y.end());
    double y_max = *std::max_element(y.begin(), y.end());
    double margin = (y_max - y_min) * 0.1;
    customPlot->yAxis->setRange(y_min - margin, y_max + margin);


    customPlot->xAxis->grid()->setVisible(true);
    customPlot->yAxis->grid()->setVisible(true);


    customPlot->xAxis->grid()->setZeroLinePen(QPen(Qt::black, 1));
    customPlot->yAxis->grid()->setZeroLinePen(QPen(Qt::black, 1));

    customPlot->setInteractions(QCP::iRangeDrag | QCP::iRangeZoom);


    customPlot->replot(); // se muestra el grafico
}
