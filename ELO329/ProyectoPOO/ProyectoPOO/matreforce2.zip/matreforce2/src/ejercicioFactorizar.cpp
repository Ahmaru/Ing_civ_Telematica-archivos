#include "ejercicios.h"
#include <cmath>
#include <ctime>

ejercicioFactorizar::ejercicioFactorizar(int tipo){
    variedad = 2;

    std::srand(static_cast<unsigned int>(std::time(nullptr)));

    if(tipo == 0){
        this->tipo = (std::rand() % variedad) + 1;
    }
    else{
        this->tipo = tipo;
    }


    switch(this->tipo){
    case 1:
    {
        int potencia_1 = (std::rand() % 10) + 1;
        int potencia_2 = (std::rand() % 10) + 1;

        int suma_exponentes = potencia_1 + potencia_2;

        int Base = (std::rand() % 100) - 1;


        enunciado = "Como se podria factorizar " + std::to_string(Base) + "^" + std::to_string(potencia_1) + " * " + std::to_string(Base) + "^" + std::to_string(potencia_2) + "?";
        soluciones->push_back(std::to_string(Base) + "^" + std::to_string(suma_exponentes));
        break;
    }
    case 2:
    {
        int a;
        a = rand() % 9 + 1;  // Coeficiente a aleatorio entre 1 y 5

        std::string trinomio_factorizado = "(x + "  + std::to_string(a) + ")^2";

        enunciado = "Como se podria factorizar x² + " + std::to_string(2*a) + "x + " + std::to_string((int)pow(a, 2)) + "?";
        soluciones->push_back(trinomio_factorizado);
        break;
    }
}
}
