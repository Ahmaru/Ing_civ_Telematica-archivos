#include "ejercicios.h"
#include <cmath>
#include <ctime>

ejercicioSistemaEcuaciones::ejercicioSistemaEcuaciones(int tipo){
    variedad = 3;
    std::srand(static_cast<unsigned int>(std::time(nullptr)));

    if (tipo == 0){
        this->tipo = std::rand() % variedad + 1;
    } else{
        this->tipo = tipo;
    }

    switch (this->tipo)
    {
    case 1: //sistema 2x2 por sust
    {
        int x = std::rand() % 10 - 5;
        int y = std::rand() % 10 - 5;

        int a1 = std::rand() % 5 + 1;
        int b1 = std::rand() % 5 + 1;
        int a2 = std::rand() % 5 + 1;
        int b2 = std::rand() % 5 + 1;

        int c1 = a1 * x + b1 * y;
        int c2 = a2 * x + b2 * y;

        enunciado = "Resuelve el sistema:\n" +
                    std::to_string(a1) + "x + " + std::to_string(b1) + "y = " + std::to_string(c1) + "\n" +
                    std::to_string(a2) + "x + " + std::to_string(b2) + "y = " + std::to_string(c2);

        soluciones->push_back("x = " + std::to_string(x));
        soluciones->push_back("y = " + std::to_string(y));
        break;
    }

    case 2: //sistema simple con eliminacion
    {
        int x = std::rand() % 8 + 1;
        int y = std::rand() % 8 + 1;

        int a1 = std::rand() % 3 + 2;
        int b1 = std::rand() % 3 + 2;
        int a2 = a1;
        int b2 = -b1;

        int c1 = a1 * x + b1 * y;
        int c2 = a2 * x + b2 * y;

        enunciado = "Resuelve por eliminación:\n" +
                    std::to_string(a1) + "x + " + std::to_string(b1) + "y = " + std::to_string(c1) + "\n" +
                    std::to_string(a2) + "x + " + std::to_string(b2) + "y = " + std::to_string(c2);

        soluciones->push_back("x = " + std::to_string(x));
        soluciones->push_back("y = " + std::to_string(y));
        break;
    }

    case 3: //sistema con fracciones simples
    {
        int x = std::rand() % 6 + 1;
        int y = std::rand() % 6 + 1;

        enunciado = "Resuelve:\nx/2 + y/3 = " + std::to_string((3*x + 2*y)/6) + "\n" +
                    "x/4 + y/2 = " + std::to_string((x + 2*y)/4);

        soluciones->push_back("x = " + std::to_string(x));
        soluciones->push_back("y = " + std::to_string(y));
        break;
    }
    }
}
