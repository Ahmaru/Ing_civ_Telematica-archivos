#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "ejercicios.h"
#include <QPixmap>
#include <QMovie>
#include <QTimer>
#include <QDebug>
#include <cmath>
#include <ctime>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , tiempoRestante(60),
    listaEjercicios{"Aleatorio", "Porcentaje", "Potencia", "Factorizar", "Ecuacion", "Division", "Sistema de Ecuaciones", "Geometria", "Probabilidad", "Inecuaciones", "Trigonometria", "Logaritmos", "Grafico"},
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->gen_combEjercicios->addItems(listaEjercicios);
    ui->widget_grafico->hide();
    
    // Gif animado del menu
    movie = new QMovie(":/resources/logo.gif");
    if (movie->isValid()) {
        ui->label_4->setMovie(movie);
        ui->label_4->setScaledContents(true); // Para que se ajuste al tamaño del label
        movie->start();

    } else {
        qDebug() << "Error no se pudo cargar el GIF desde :/resources/logo.gif";
        ui->label_4->setText("LOGO");
    }

    ContadorSoluciones = 1;

    // Generador
    connect(ui->gen_pushGenerar, &QPushButton::clicked, this, &MainWindow::Generar);
    connect(ui->gen_pushResultado, &QPushButton::clicked, this, &MainWindow::showSolucionGenerador);
    connect(ui->gen_combEjercicios, QOverload<int>::of(&QComboBox::activated), this, &MainWindow::actualizarTipos);
    connect(ui->gen_pushVolver, &QPushButton::clicked, this, &MainWindow::IrMenu);
    connect(ui->botonGenerador, &QPushButton::clicked, this, &MainWindow::IrGenerador);
    connect(ui->BotonDesafio, &QPushButton::clicked, this, &MainWindow::IrDesafio);
    connect(ui->BotonIniciar, &QPushButton::clicked, this, &MainWindow::InicioDesafio);
    connect(ui->BotonEnviarRespuesta, &QPushButton::clicked, this, &MainWindow::VerificarRespuesta);
    connect(ui->SalirDesafio, &QPushButton::clicked, this, &MainWindow::SalirDesafio);

    // Tiempo del desafio
    TiempoDesafioNumero = new QTimer();
    connect(TiempoDesafioNumero, &QTimer::timeout, this, &MainWindow::ActualizarTiempo);

    // No iniciar el timer aquí, solo cuando se inicie el desafío
    ActualizarLabelTiempo();

    std::srand(static_cast<unsigned int>(std::time(nullptr)));
}

void MainWindow::setSoluciones(ejercicio *actual){
    std::vector<std::string>* temp = actual->getSoluciones();
    std::vector<QString> final;
    for (int i = 0; i<temp->size(); i++){
        final.push_back(QString::fromStdString(temp->at(i)));
    }
    this->soluciones = final;
}

void MainWindow::IrMenu(){
    ui->stackedWidget->setCurrentWidget(ui->Menu);
}

//Botones Menu Principal
void MainWindow::IrGenerador(){
    ui->stackedWidget->setCurrentIndex(0);
}

void MainWindow::IrDesafio(){
    ui->stackedWidget->setCurrentIndex(1);
}

void MainWindow::InicioDesafio(){
    //Variables que usa Modo Desafio
    ui->BotonEnviarRespuesta->setEnabled(true);
    Puntaje = 0;
    MultiplicadorPuntaje = 1;
    tiempoRestante = 60;
    EjerciciosResueltosDesafio = 0;
    ActualizarPuntaje();

    ui->stackedWidget->setCurrentIndex(2);
    EnDesafio = true;
    IniciarTiempoDesafio();
    EleccionProblemaAleatorio();
}

//shows

void MainWindow::showEnunciado(ejercicio *actual, QLabel* label){
    label->setText(QString::fromStdString(actual->getEnunciado()));
    label->adjustSize();
}

MainWindow::~MainWindow()
{
    if (movie) {
        delete movie;
    }
    delete ui;
}
