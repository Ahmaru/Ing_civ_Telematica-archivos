#include "ejercicios.h"
#include <cmath>
#include <ctime>
#include <QDebug>

ejercicioDivisiones::ejercicioDivisiones(int tipo){
    variedad = 2;

    std::srand(static_cast<unsigned int>(std::time(nullptr)));

    if(tipo == 0){
        this->tipo = (std::rand() % variedad) + 1;
    }
    else{
        this->tipo = tipo;
    }




    switch(this->tipo){
    case 1:
    {
        int Dividendo_1 = (std::rand() % 10) + 1;
        int Divisor_1 = (std::rand() % 10) + 1;
        int Dividendo_2 = (std::rand() % 10) + 1;
        int Divisor_2 = (std::rand() % 10) + 1;

        int SolucionDivisionesArriba = (((Dividendo_1*Divisor_2)+(Divisor_1*Dividendo_2)));
        int SolucionDivisionAbajo = (Divisor_1*Divisor_2);



        enunciado = "La suma de " + std::to_string(Dividendo_1) + "/" + std::to_string(Divisor_1) + " + " + std::to_string(Dividendo_2) + "/" + std::to_string(Divisor_2) + "?";
        soluciones->push_back(std::to_string(SolucionDivisionesArriba) + "/" + std::to_string(SolucionDivisionAbajo));
        break;
    }
    case 2:
    {
        int Dividendo_1 = (std::rand() % 10) + 1;
        int Divisor_1 = (std::rand() % 10) + 1;
        int Dividendo_2 = (std::rand() % 10) + 1;
        int Divisor_2 = (std::rand() % 10) + 1;

        int SolucionDivisionesArriba = (((Dividendo_1*Divisor_2)-(Divisor_1*Dividendo_2)));
        int SolucionDivisionAbajo = (Divisor_1*Divisor_2);


        enunciado = "La resta de " + std::to_string(Dividendo_1) + "/" + std::to_string(Divisor_1) + " - " + std::to_string(Dividendo_2) + "/" + std::to_string(Divisor_2) + "?";
        soluciones->push_back(std::to_string(SolucionDivisionesArriba) + "/" + std::to_string(SolucionDivisionAbajo));
        break;
    }
    }
}
