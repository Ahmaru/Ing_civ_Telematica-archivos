#include "ejercicios.h"
#include <cmath>
#include <ctime>

ejercicioTrigonometria::ejercicioTrigonometria(int tipo){
    variedad = 6;
    std::srand(static_cast<unsigned int>(std::time(nullptr)));

    if (tipo == 0){
        this->tipo = std::rand() % variedad + 1;
    } else{
        this->tipo = tipo;
    }

    switch (this->tipo)
    {
    case 1: //razones trigonometricas simples
    {

        int triangulos[][3] = {{3,4,5}, {5,12,13}, {8,15,17}, {7,24,25}};
        int indice = std::rand() % 4;

        int cateto_opuesto = triangulos[indice][0];
        int cateto_adyacente = triangulos[indice][1];
        int hipotenusa = triangulos[indice][2];

        int funcion = std::rand() % 3;

        switch(funcion) {
        case 0:
            enunciado = "En un triángulo rectángulo, el cateto opuesto es " + std::to_string(cateto_opuesto) +
                        " y la hipotenusa es " + std::to_string(hipotenusa) + ". Calcula sen(θ)";
            soluciones->push_back(formatearFraccion(cateto_opuesto, hipotenusa));
            break;
        case 1:
            enunciado = "En un triángulo rectángulo, el cateto adyacente es " + std::to_string(cateto_adyacente) +
                        " y la hipotenusa es " + std::to_string(hipotenusa) + ". Calcula cos(θ)";
            soluciones->push_back(formatearFraccion(cateto_adyacente, hipotenusa));
            break;
        case 2:
            enunciado = "En un triángulo rectángulo, el cateto opuesto es " + std::to_string(cateto_opuesto) +
                        " y el cateto adyacente es " + std::to_string(cateto_adyacente) + ". Calcula tan(θ)";
            soluciones->push_back(formatearFraccion(cateto_opuesto, cateto_adyacente));
            break;
        }
        break;
    }

    case 2: //angulos notables
    {
        struct AnguloNotable {
            int grados;
            std::string radianes;
            std::string seno;
            std::string coseno;
            std::string tangente;
        };

        AnguloNotable angulos[] = {
            {30, "π/6", "1/2", "√3/2", "√3/3"},
            {45, "π/4", "√2/2", "√2/2", "1"},
            {60, "π/3", "√3/2", "1/2", "√3"}
        };

        int indice = std::rand() % 3;
        int funcion = std::rand() % 3;

        switch(funcion) {
        case 0:
            enunciado = "Calcula sen(" + std::to_string(angulos[indice].grados) + "°)";
            soluciones->push_back(angulos[indice].seno);
            break;
        case 1:
            enunciado = "Calcula cos(" + std::to_string(angulos[indice].grados) + "°)";
            soluciones->push_back(angulos[indice].coseno);
            break;
        case 2:
            enunciado = "Calcula tan(" + std::to_string(angulos[indice].grados) + "°)";
            soluciones->push_back(angulos[indice].tangente);
            break;
        }
        break;
    }

    case 3: //identidades trigonometricas simples
    {
        int tipo_identidad = std::rand() % 3;

        switch(tipo_identidad) {
        case 0:
            enunciado = "Verifica la identidad: sen²(θ) + cos²(θ) = ?";
            soluciones->push_back("1");
            break;
        case 1:
            enunciado = "Simplifica: tan(θ) = ?";
            soluciones->push_back("sen(θ)/cos(θ)");
            break;
        case 2:
            enunciado = "Si sen(θ) = 3/5, calcula cos²(θ)";
            soluciones->push_back("16/25");
            break;
        }
        break;
    }

    case 4: //ecuaciones trigonometricas simples
    {
        int tipo_ecuacion = std::rand() % 3;

        switch(tipo_ecuacion) {
        case 0:
            enunciado = "Resuelve: sen(x) = 1/2 (0° ≤ x ≤ 360°)";
            soluciones->push_back("x = 30°, 150°");
            break;
        case 1:
            enunciado = "Resuelve: cos(x) = √2/2 (0° ≤ x ≤ 360°)";
            soluciones->push_back("x = 45°, 315°");
            break;
        case 2:
            enunciado = "Resuelve: tan(x) = 1 (0° ≤ x ≤ 360°)";
            soluciones->push_back("x = 45°, 225°");
            break;
        }
        break;
    }

    case 5: //converit de grados a radian
    {
        int grados[] = {30, 45, 60, 90, 120, 135, 150, 180};
        std::string radianes[] = {"π/6", "π/4", "π/3", "π/2", "2π/3", "3π/4", "5π/6", "π"};

        int indice = std::rand() % 8;
        bool grados_a_radianes = std::rand() % 2;

        if (grados_a_radianes) {
            enunciado = "Convierte " + std::to_string(grados[indice]) + "° a radianes";
            soluciones->push_back(radianes[indice]);
        } else {
            enunciado = "Convierte " + radianes[indice] + " rad a grados";
            soluciones->push_back(std::to_string(grados[indice]) + "°");
        }
        break;
    }

    case 6: // triangulos
    {
        int altura = std::rand() % 20 + 10;
        int angulo = std::rand() % 3;
        int angulos_grados[] = {30, 45, 60};
        std::string distancias[] = {"2h", "h", "h/√3"};

        enunciado = "Desde un punto en el suelo, se observa la cima de un edificio con un ángulo de elevación de " +
                    std::to_string(angulos_grados[angulo]) + "°. Si la altura del edificio es " +
                    std::to_string(altura) + " m, ¿cuál es la distancia horizontal?";

        switch(angulo) {
        case 0: // 30°
            soluciones->push_back(std::to_string(altura * 1732 / 1000) + " m");
            break;
        case 1: // 45°
            soluciones->push_back(std::to_string(altura) + " m");
            break;
        case 2: // 60°
            soluciones->push_back(std::to_string(altura * 577 / 1000) + " m");
            break;
        }
        break;
    }
    }
}
