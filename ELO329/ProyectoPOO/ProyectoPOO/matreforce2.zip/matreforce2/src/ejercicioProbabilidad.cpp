#include "ejercicios.h"
#include <cmath>
#include <ctime>

ejercicioProbabilidad::ejercicioProbabilidad(int tipo){
    variedad = 5;
    std::srand(static_cast<unsigned int>(std::time(nullptr)));

    if (tipo == 0){
        this->tipo = std::rand() % variedad + 1;
    } else{
        this->tipo = tipo;
    }

    switch (this->tipo)
    {
    case 1: //probabilidad simple con dados
    {
        int suma_deseada = std::rand() % 6 + 7;
        int casos_favorables = 0;

        //Contar casos favorables
        for (int i = 1; i <= 6; i++) {
            for (int j = 1; j <= 6; j++) {
                if (i + j == suma_deseada) {
                    casos_favorables++;
                }
            }
        }

        enunciado = "Al lanzar dos dados, ¿cuál es la probabilidad de obtener una suma de " +
                    std::to_string(suma_deseada) + "?";

        soluciones->push_back(formatearFraccion(casos_favorables, 36));
        break;
    }

    case 2: //probabilidad con cartas
    {
        std::string tipos[] = {"corazones", "diamantes", "tréboles", "espadas"};
        int tipo_elegido = std::rand() % 4;

        enunciado = "De una baraja de 52 cartas, ¿cuál es la probabilidad de sacar una carta de " +
                    tipos[tipo_elegido] + "?";

        soluciones->push_back(formatearFraccion(13, 52)); // Simplifica a 1/4
        break;
    }

    case 3: //probabilidad con bolitas
    {
        int rojas = std::rand() % 8 + 2;
        int azules = std::rand() % 8 + 2;
        int total = rojas + azules;

        enunciado = "En una bolsa hay " + std::to_string(rojas) + " bolitas rojas y " +
                    std::to_string(azules) + " bolitas azules. ¿Cuál es la probabilidad de sacar una bolita roja?";

        soluciones->push_back(formatearFraccion(rojas, total));
        break;
    }

    case 4: //probabilidad de eventos complementarios
    {
        int exitos = std::rand() % 15 + 5;
        int total = exitos + std::rand() % 20 + 10;
        int fracasos = total - exitos;

        enunciado = "Si la probabilidad de éxito es " + formatearFraccion(exitos, total) +
                    ", ¿cuál es la probabilidad de fracaso?";

        soluciones->push_back(formatearFraccion(fracasos, total));
        break;
    }

    case 5: //probabilidad eventos independientes entre si
    {
        int prob1_num = std::rand() % 3 + 1;
        int prob1_den = std::rand() % 3 + 4;
        int prob2_num = std::rand() % 3 + 1;
        int prob2_den = std::rand() % 3 + 4;

        int resultado_num = prob1_num * prob2_num;
        int resultado_den = prob1_den * prob2_den;

        enunciado = "Si la probabilidad del evento A es " + formatearFraccion(prob1_num, prob1_den) +
                    " y la del evento B es " + formatearFraccion(prob2_num, prob2_den) +
                    ", ¿cuál es la probabilidad de que ocurran ambos eventos (independientes)?";

        soluciones->push_back(formatearFraccion(resultado_num, resultado_den));
        break;
    }
    }
}
