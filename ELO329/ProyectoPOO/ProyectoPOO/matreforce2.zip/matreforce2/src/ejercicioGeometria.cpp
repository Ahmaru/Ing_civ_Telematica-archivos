#include "ejercicios.h"
#include <cmath>
#include <ctime>
#include <iomanip>
#include <sstream>

ejercicioGeometria::ejercicioGeometria(int tipo){
    variedad = 6;
    std::srand(static_cast<unsigned int>(std::time(nullptr)));

    if (tipo == 0){
        this->tipo = std::rand() % variedad + 1;
    } else{
        this->tipo = tipo;
    }

    switch (this->tipo)
    {
    case 1: // Área de triángulo
    {
        int base = std::rand() % 20 + 5;
        int altura = std::rand() % 20 + 5;
        double area = (base * altura) / 2.0;

        enunciado = "Calcula el área de un triángulo con base " + std::to_string(base) + " cm y altura " + std::to_string(altura) + " cm.";

        if (area == (int)area) {
            soluciones->push_back(std::to_string((int)area) + " cm²");
        } else {
            std::ostringstream oss;
            oss << std::fixed << std::setprecision(1) << area;
            soluciones->push_back(oss.str() + " cm²");
        }
        break;
    }

    case 2: // Área de círculo
    {
        int radio = std::rand() % 10 + 3;
        double area = M_PI * radio * radio;

        enunciado = "Calcula el área de un círculo con radio " + std::to_string(radio) + " cm. (π ≈ 3.14159)";

        std::ostringstream oss;
        oss << std::fixed << std::setprecision(2) << area;
        soluciones->push_back(oss.str() + " cm²");
        break;
    }

    case 3: // Perímetro de rectángulo
    {
        int largo = std::rand() % 20 + 5;
        int ancho = std::rand() % 15 + 3;
        int perimetro = 2 * (largo + ancho);

        enunciado = "Calcula el perímetro de un rectángulo de " + std::to_string(largo) + " cm de largo y " + std::to_string(ancho) + " cm de ancho.";
        soluciones->push_back(std::to_string(perimetro) + " cm");
        break;
    }

    case 4: // Teorema de Pitágoras
    {
        // Generar tríos pitagóricos conocidos
        int trios[][3] = {{3,4,5}, {5,12,13}, {8,15,17}, {7,24,25}, {6,8,10}};
        int indice = std::rand() % 5;

        int lado_conocido = std::rand() % 2; // 0 o 1

        if (lado_conocido == 0) {
            enunciado = "En un triángulo rectángulo, un cateto mide " + std::to_string(trios[indice][0]) +
                        " cm y el otro cateto mide " + std::to_string(trios[indice][1]) + " cm. ¿Cuál es la hipotenusa?";
            soluciones->push_back(std::to_string(trios[indice][2]) + " cm");
        } else {
            enunciado = "En un triángulo rectángulo, la hipotenusa mide " + std::to_string(trios[indice][2]) +
                        " cm y un cateto mide " + std::to_string(trios[indice][0]) + " cm. ¿Cuál es el otro cateto?";
            soluciones->push_back(std::to_string(trios[indice][1]) + " cm");
        }
        break;
    }

    case 5: // Volumen de prisma rectangular
    {
        int largo = std::rand() % 10 + 3;
        int ancho = std::rand() % 10 + 3;
        int alto = std::rand() % 10 + 3;
        int volumen = largo * ancho * alto;

        enunciado = "Calcula el volumen de un prisma rectangular de " + std::to_string(largo) +
                    " cm de largo, " + std::to_string(ancho) + " cm de ancho y " + std::to_string(alto) + " cm de alto.";
        soluciones->push_back(std::to_string(volumen) + " cm³");
        break;
    }

    case 6: // Ángulos en triángulo
    {
        int angulo1 = std::rand() % 80 + 30;
        int angulo2 = std::rand() % (150 - angulo1) + 20;
        int angulo3 = 180 - angulo1 - angulo2;

        enunciado = "En un triángulo, dos ángulos miden " + std::to_string(angulo1) + "° y " +
                    std::to_string(angulo2) + "°. ¿Cuál es el tercer ángulo?";
        soluciones->push_back(std::to_string(angulo3) + "°");
        break;
    }
    }
}
