#include "mainwindow.h"
#include "ui_mainwindow.h"

void MainWindow::showSolucionGenerador(){

    QString finalText = this->soluciones.at(0);
    for(int i = 1; i<soluciones.size(); i++){
        finalText = finalText + ", " + soluciones.at(i);
    }
    ui->gen_labSolucion->setText(finalText);
    ui->gen_labSolucion->adjustSize();
}
// gens
void MainWindow::genEcuacion(int tipo){
    ejercicioEcuacion *ejercicio = new ejercicioEcuacion(tipo);
    ui->widget_grafico->hide();
    showEnunciado(ejercicio, ui->gen_labEnunciado);
    setSoluciones(ejercicio);
    ui->gen_labSolucion->setText("");

    delete ejercicio;
}

void MainWindow::genPorcentaje(int tipo){
    ejercicioPorcentaje *ejercicio = new ejercicioPorcentaje(tipo);
    showEnunciado(ejercicio, ui->gen_labEnunciado);
    ui->widget_grafico->hide();
    setSoluciones(ejercicio);
    ui->gen_labSolucion->setText("");
    delete ejercicio;
}

void MainWindow::genPotencia(int tipo){
    ejercicioPotencia *ejercicio = new ejercicioPotencia(tipo);
    showEnunciado(ejercicio, ui->gen_labEnunciado);
    ui->widget_grafico->hide();
    setSoluciones(ejercicio);
    ui->gen_labSolucion->setText("");
    delete ejercicio;
}

void MainWindow::genFactorizar(int tipo){
    ejercicioFactorizar *ejercicio = new ejercicioFactorizar(tipo);
    showEnunciado(ejercicio,ui->gen_labEnunciado);
    ui->widget_grafico->hide();
    setSoluciones(ejercicio);
    ui->gen_labSolucion->setText("");
    delete ejercicio;
}
void MainWindow::genDivisiones(int tipo){
    ejercicioDivisiones *ejercicio = new ejercicioDivisiones(tipo);
    showEnunciado(ejercicio,ui->gen_labEnunciado);
    ui->widget_grafico->hide();
    setSoluciones(ejercicio);
    ui->gen_labSolucion->setText("");
    delete ejercicio;
}

void MainWindow::genGrafico(int tipo){
    ejercicioEcuacionGrafico *ejercicio = new ejercicioEcuacionGrafico(tipo, ui);
    showEnunciado(ejercicio,ui->gen_labEnunciado);
    setSoluciones(ejercicio);
    ui->gen_labSolucion->setText("");
    delete ejercicio;

}
void MainWindow::genSistemaEcuaciones(int tipo){
    ejercicioSistemaEcuaciones *ejercicio = new ejercicioSistemaEcuaciones(tipo);
    showEnunciado(ejercicio, ui->gen_labEnunciado);
    setSoluciones(ejercicio);
    ui->gen_labSolucion->setText("");
    delete ejercicio;
}

void MainWindow::genGeometria(int tipo){
    ejercicioGeometria *ejercicio = new ejercicioGeometria(tipo);
    showEnunciado(ejercicio, ui->gen_labEnunciado);
    setSoluciones(ejercicio);
    ui->gen_labSolucion->setText("");
    delete ejercicio;
}

void MainWindow::genProbabilidad(int tipo){
    ejercicioProbabilidad *ejercicio = new ejercicioProbabilidad(tipo);
    showEnunciado(ejercicio, ui->gen_labEnunciado);
    setSoluciones(ejercicio);
    ui->gen_labSolucion->setText("");
    delete ejercicio;
}

void MainWindow::genInecuaciones(int tipo){
    ejercicioInecuaciones *ejercicio = new ejercicioInecuaciones(tipo);
    showEnunciado(ejercicio, ui->gen_labEnunciado);
    setSoluciones(ejercicio);
    ui->gen_labSolucion->setText("");
    delete ejercicio;
}

void MainWindow::genTrigonometria(int tipo){
    ejercicioTrigonometria *ejercicio = new ejercicioTrigonometria(tipo);
    showEnunciado(ejercicio, ui->gen_labEnunciado);
    setSoluciones(ejercicio);
    ui->gen_labSolucion->setText("");
    delete ejercicio;
}
void MainWindow::genLogaritmos(int tipo){
    ejercicioLogaritmos *ejercicio = new ejercicioLogaritmos(tipo);
    showEnunciado(ejercicio, ui->gen_labEnunciado);
    setSoluciones(ejercicio);
    ui->gen_labSolucion->setText("");
    delete ejercicio;
}

void MainWindow::actualizarTipos(){
    ui->gen_combTipo->clear();
    switch(ui->gen_combEjercicios->currentIndex()){
    case 0:
        ui->gen_combTipo->addItems(QStringList{"Aleatorio"});
        break;
    case 1:
        ui->gen_combTipo->addItems(QStringList{"Aleatorio", "Cuanto es el x% de y?", "Que porcentaje es x respecto a y?", "Si x es el y% de un numero, cual es el numero?"});
        break;
    case 2:
        ui->gen_combTipo->addItems(QStringList{"Aleatorio", "Cuanto es x elevado a y?"});
        break;
    case 3:
        ui->gen_combTipo->addItems(QStringList{"Aleatorio", "Como se podria factorizar (x^a)*(x^b)?" , "Como se podria factorizar x² + bx + c?"});
        break;
    case 4:
        ui->gen_combTipo->addItems(QStringList{"Aleatorio", "Encuentre las raices de x² + bx + c"});
        break;
    case 5:
        ui->gen_combTipo->addItems(QStringList{"Aleatorio", "La suma de a/b + c/d", "La resta de a/b + c/d"});
        break;
    case 6:
        ui->gen_combTipo->addItems(QStringList{"Aleatorio", "Sistema 2x2 por sustitución", "Sistema simple con eliminación", "Sistema con fracciones simples"});
        break;
    case 7:
        ui->gen_combTipo->addItems(QStringList{"Aleatorio", "Área de triángulo", "Área de círculo", "Perímetro de rectángulo", "Teorema de Pitágoras", "Volumen de prisma rectangular", "Ángulos en triángulo"});
        break;
    case 8:
        ui->gen_combTipo->addItems(QStringList{"Aleatorio", "Probabilidad simple con dados", "Probabilidad con cartas", "Probabilidad con bolitas", "Probabilidad de eventos complementarios", "Probabilidad de eventos independientes"});
        break;
    case 9:
        ui->gen_combTipo->addItems(QStringList{"Aleatorio", "Inecuaciones lineales", "Inecuaciones cuadráticas", "Inecuaciones con valor absoluto", "Inecuaciones con fracción", "Sistema de inecuaciones"});
        break;
    case 10:
        ui->gen_combTipo->addItems(QStringList{"Aleatorio", "Razones trigonométricas", "Ángulos notables", "Identidades trigonométricas", "Ecuaciones trigonométricas", "Conversión de grados a radianes", "Triángulos"});
        break;
    case 11:
        ui->gen_combTipo->addItems(QStringList{"Aleatorio", "Logaritmos básicos", "Propiedades logarítimicas(suma)", "Propieades logarítmicas(resta)", "ecuaciones logarítmicas", "Cambio de base", "Logaritmo natural"});
    case 12:
        ui->gen_combTipo->addItems(QStringList{"Aleatorio", "Encontrar función"});
    }
    ui->gen_combTipo->setCurrentIndex(0);
}
void MainWindow::Generar(){
    int index = ui->gen_combEjercicios->currentIndex();
    if (index == 0){
        index = std::rand() % 8 + 1;
    }

    switch(index){
    case 1:
        genPorcentaje(ui->gen_combTipo->currentIndex());
        break;
    case 2:
        genPotencia(ui->gen_combTipo->currentIndex());
        break;
    case 3:
        genFactorizar(ui->gen_combTipo->currentIndex());
        break;
    case 4:
        genEcuacion(ui->gen_combTipo->currentIndex());
        break;
    case 5:
        genDivisiones(ui->gen_combTipo->currentIndex());
        break;
    case 6:
        genSistemaEcuaciones(ui->gen_combTipo->currentIndex());
        break;
    case 7:
        genGeometria(ui->gen_combTipo->currentIndex());
        break;
    case 8:
        genProbabilidad(ui->gen_combTipo->currentIndex());
        break;
    case 9:
        genInecuaciones(ui->gen_combTipo->currentIndex());
        break;
    case 10:
        genTrigonometria(ui->gen_combTipo->currentIndex());
        break;
    case 11:
        genLogaritmos(ui->gen_combTipo->currentIndex());
        break;
    case 12:
        genGrafico(ui->gen_combTipo->currentIndex());
        break;
    }
}
