#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "ejercicios.h"
#include <QPixmap>
#include <QTimer>
#include <cmath>
#include <ctime>
#include <QDebug>
#include <QString>

//Funciones del tiempo
void MainWindow::IniciarTiempoDesafio(){

    TiempoDesafioNumero->start(1000);

}

void MainWindow::ActualizarTiempo(){

    if(tiempoRestante > 0){
        tiempoRestante--;
        ActualizarLabelTiempo();
    }
    else{
        TiempoDesafioNumero->stop();
        ui->EnunciadoDesafio->setText("Se termino el tiempo!\nEjercicios Resueltos: " + QString::number(EjerciciosResueltosDesafio));
        ui->BotonEnviarRespuesta->setEnabled(false);
    }
}

void MainWindow::ActualizarLabelTiempo(){

    ui->TiempoDesafio->setText(QString("Tiempo restante: %1 segundos").arg(tiempoRestante));
}

//Modo desafio eleccion de enunciado

void MainWindow::EleccionProblemaAleatorio(){
    EnunciadoPuesto = false;

    if(EnunciadoPuesto == false){
        int EleccionProblema = (std::rand() % 8) + 1; // Cambiado de 5 a 8

        switch(EleccionProblema){
        case 1:{
            EnunciadoPuesto = true;
            ejercicioEcuacion *ecuacion = new ejercicioEcuacion;
            setSoluciones(ecuacion);
            ui->EnunciadoDesafio->setText(QString::fromStdString(ecuacion->getEnunciado()));
            ui->EnunciadoDesafio->adjustSize();
            delete ecuacion;
            break;
        }
        case 2:{
            EnunciadoPuesto = true;
            ejercicioPorcentaje *ejercicio = new ejercicioPorcentaje;
            setSoluciones(ejercicio);
            ui->EnunciadoDesafio->setText(QString::fromStdString(ejercicio->getEnunciado()));
            ui->EnunciadoDesafio->adjustSize();
            delete ejercicio;
            break;
        }
        case 3:{
            EnunciadoPuesto = true;
            ejercicioPotencia *ejercicio = new ejercicioPotencia;
            setSoluciones(ejercicio);
            ui->EnunciadoDesafio->setText(QString::fromStdString(ejercicio->getEnunciado()));
            ui->EnunciadoDesafio->adjustSize();
            delete ejercicio;
            break;
        }
        case 4:{
            EnunciadoPuesto = true;
            ejercicioFactorizar *ejercicio = new ejercicioFactorizar;
            setSoluciones(ejercicio);
            ui->EnunciadoDesafio->setText(QString::fromStdString(ejercicio->getEnunciado()));
            ui->EnunciadoDesafio->adjustSize();
            delete ejercicio;
            break;
        }
        case 5:{
            EnunciadoPuesto = true;
            ejercicioDivisiones *ejercicio = new ejercicioDivisiones;
            setSoluciones(ejercicio);
            ui->EnunciadoDesafio->setText(QString::fromStdString(ejercicio->getEnunciado()));
            ui->EnunciadoDesafio->adjustSize();
            delete ejercicio;
            break;
        }
        case 6:{
            EnunciadoPuesto = true;
            ejercicioSistemaEcuaciones *ejercicio = new ejercicioSistemaEcuaciones;
            setSoluciones(ejercicio);
            ui->EnunciadoDesafio->setText(QString::fromStdString(ejercicio->getEnunciado()));
            ui->EnunciadoDesafio->adjustSize();
            delete ejercicio;
            break;
        }
        case 7:{
            EnunciadoPuesto = true;
            ejercicioGeometria *ejercicio = new ejercicioGeometria;
            setSoluciones(ejercicio);
            ui->EnunciadoDesafio->setText(QString::fromStdString(ejercicio->getEnunciado()));
            ui->EnunciadoDesafio->adjustSize();
            delete ejercicio;
            break;
        }
        case 8:{
            EnunciadoPuesto = true;
            ejercicioProbabilidad *ejercicio = new ejercicioProbabilidad;
            setSoluciones(ejercicio);
            ui->EnunciadoDesafio->setText(QString::fromStdString(ejercicio->getEnunciado()));
            ui->EnunciadoDesafio->adjustSize();
            delete ejercicio;
            break;
        }
        };
    }
}
void MainWindow::ActualizarPuntaje(){

    ui->PuntajeUsuario->setText("Puntaje: " + QString::number(Puntaje) + " x " + QString::number(MultiplicadorPuntaje));
}

void MainWindow::VerificarRespuesta(){

    QString Respuesta = ui->RespuestaUsuario->text();

    QString Solucion;

    for(int i = 0; i < this->soluciones.size(); i++){

        Solucion += soluciones[i];

        if(i < this->soluciones.size() - 1){

            Solucion += ", ";
        }

    }

    qDebug() << Solucion;

    qDebug() << Respuesta;

    if(Respuesta == Solucion){
        EjerciciosResueltosDesafio++;
        MultiplicadorPuntaje += 1;
        Puntaje += 100*MultiplicadorPuntaje;
        ActualizarPuntaje();

        tiempoRestante += 15;

        ui->VerificadorVisual->setText("Correcto");

        EleccionProblemaAleatorio();
    }
    else{
        MultiplicadorPuntaje = 1;
        ui->VerificadorVisual->setText("Incorrecto");
    }
}

void MainWindow::SalirDesafio(){
    TiempoDesafioNumero->stop();
    ui->stackedWidget->setCurrentIndex(3);

}


