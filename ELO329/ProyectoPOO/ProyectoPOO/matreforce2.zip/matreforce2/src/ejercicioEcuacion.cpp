#include "ejercicios.h"
#include <cmath>
#include <ctime>
#include <iomanip>
#include <sstream>

ejercicioEcuacion::ejercicioEcuacion(int tipo){
    variedad = 4;
    std::srand(static_cast<unsigned int>(std::time(nullptr)));

    if (tipo == 0){
        this->tipo = std::rand() % variedad + 1;
    } else{
        this->tipo = tipo;
    }

    switch (this->tipo)
    {
    case 1: // Ecuaciones cuadráticas con raíces enteras
    {
        int a = std::rand() % 9 - 4; // Entre -4 y 4, excluyendo 0
        int b = std::rand() % 9 - 4;
        while (a == 0) a = std::rand() % 9 - 4;
        while (b == 0) b = std::rand() % 9 - 4;

        int coef_x = -(a + b);
        int coef_independiente = a * b;

        std::string termino_x = "";
        std::string termino_indep = "";

        if (coef_x > 0) termino_x = "+" + std::to_string(coef_x) + "x";
        else if (coef_x < 0) termino_x = std::to_string(coef_x) + "x";

        if (coef_independiente > 0) termino_indep = "+" + std::to_string(coef_independiente);
        else if (coef_independiente < 0) termino_indep = std::to_string(coef_independiente);

        enunciado = "Encuentra las raíces de: x²" + termino_x + termino_indep + " = 0";

        if (a < b) {
            soluciones->push_back(std::to_string(a));
            soluciones->push_back(std::to_string(b));
        } else {
            soluciones->push_back(std::to_string(b));
            soluciones->push_back(std::to_string(a));
        }
        break;
    }

    case 2: // Ecuaciones lineales simples
    {
        int a = std::rand() % 10 + 1;
        int b = std::rand() % 20 - 10;
        int c = std::rand() % 30 - 15;
        int x = (c - b) / a;

        std::string termino_b = "";
        if (b > 0) termino_b = "+" + std::to_string(b);
        else if (b < 0) termino_b = std::to_string(b);

        enunciado = "Resuelve: " + std::to_string(a) + "x" + termino_b + " = " + std::to_string(c);
        soluciones->push_back(std::to_string(x));
        break;
    }

    case 3: // Ecuaciones con fracciones
    {
        int num1 = std::rand() % 9 + 1;
        int den1 = std::rand() % 9 + 2;
        int num2 = std::rand() % 9 + 1;
        int den2 = std::rand() % 9 + 2;

        // x/den1 + num1 = num2/den2
        // x = (num2/den2 - num1) * den1

        enunciado = "Resuelve: x/" + std::to_string(den1) + " + " + std::to_string(num1) + " = " + std::to_string(num2) + "/" + std::to_string(den2);

        // Calcular resultado como fracción
        int resultado_num = num2 * den1 - num1 * den2 * den1;
        int resultado_den = den2;

        soluciones->push_back(formatearFraccion(resultado_num, resultado_den));
        break;
    }

    case 4: // Ecuaciones con valor absoluto
    {
        int a = std::rand() % 10 + 1;
        int b = std::rand() % 20 + 1;

        enunciado = std::string("Resuelve: |x ") + (a > 0 ? "- " : "+ ") + std::to_string(abs(a)) + "| = " + std::to_string(b);


        int sol1 = b - a;
        int sol2 = -b - a;

        if (sol1 < sol2) {
            soluciones->push_back(std::to_string(sol1));
            soluciones->push_back(std::to_string(sol2));
        } else {
            soluciones->push_back(std::to_string(sol2));
            soluciones->push_back(std::to_string(sol1));
        }
        break;
    }
    }
}
