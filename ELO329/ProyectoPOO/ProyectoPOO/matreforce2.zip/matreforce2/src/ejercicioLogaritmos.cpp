#include "ejercicios.h"
#include <cmath>
#include <ctime>

ejercicioLogaritmos::ejercicioLogaritmos(int tipo){
    variedad = 6;
    std::srand(static_cast<unsigned int>(std::time(nullptr)));

    if (tipo == 0){
        this->tipo = std::rand() % variedad + 1;
    } else{
        this->tipo = tipo;
    }

    switch (this->tipo)
    {
    case 1: //basicos
    {
        int bases[] = {2, 3, 5, 10};
        int base = bases[std::rand() % 4];
        int exponente = std::rand() % 4 + 1;
        int resultado = (int)std::pow(base, exponente);

        enunciado = "Calcula: log" + std::to_string(base) + "(" + std::to_string(resultado) + ")";
        soluciones->push_back(std::to_string(exponente));
        break;
    }

    case 2: //propiedades de logaritmos - suma
    {
        int a = std::rand() % 50 + 2;
        int b = std::rand() % 50 + 2;
        int producto = a * b;

        enunciado = "Simplifica: log(" + std::to_string(a) + ") + log(" + std::to_string(b) + ")";
        soluciones->push_back("log(" + std::to_string(producto) + ")");
        break;
    }

    case 3: //propiedades de logaritmos - resta
    {
        int a = std::rand() % 50 + 10;
        int b = std::rand() % 10 + 2;
        while (a % b != 0) {
            a = std::rand() % 50 + 10;
        }
        int cociente = a / b;

        enunciado = "Simplifica: log(" + std::to_string(a) + ") - log(" + std::to_string(b) + ")";
        soluciones->push_back("log(" + std::to_string(cociente) + ")");
        break;
    }

    case 4: //ecuaciones logaritmicas
    {
        int base = std::rand() % 3 + 2; // 2, 3, o 4
        int x = std::rand() % 10 + 1;
        int resultado = (int)std::pow(base, x);

        enunciado = "Resuelve: log" + std::to_string(base) + "(x) = " + std::to_string(x);
        soluciones->push_back("x = " + std::to_string(resultado));
        break;
    }

    case 5: //cambio de base
    {
        int base_original = std::rand() % 5 + 2;
        int nueva_base = std::rand() % 5 + 2;
        while (nueva_base == base_original) {
            nueva_base = std::rand() % 5 + 2;
        }
        int x = std::rand() % 100 + 10;

        enunciado = "Convierte a base " + std::to_string(nueva_base) + ": log" + std::to_string(base_original) + "(" + std::to_string(x) + ")";
        soluciones->push_back("log" + std::to_string(nueva_base) + "(" + std::to_string(x) + ") / log" + std::to_string(nueva_base) + "(" + std::to_string(base_original) + ")");
        break;
    }

    case 6: //logaritmo natural
    {
        int exponente = std::rand() % 5 + 1;

        enunciado = "Calcula: ln(e^" + std::to_string(exponente) + ")";
        soluciones->push_back(std::to_string(exponente));
        break;
    }
    }
}
