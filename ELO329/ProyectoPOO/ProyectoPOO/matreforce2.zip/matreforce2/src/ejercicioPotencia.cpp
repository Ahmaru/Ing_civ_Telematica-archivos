#include "ejercicios.h"
#include <cmath>
#include <ctime>
#include <QString>


ejercicioPotencia::ejercicioPotencia(int tipo){
    variedad = 1;
    // Se actualiza la semilla de aleatoriedad.
    std::srand(static_cast<unsigned int>(std::time(nullptr)));
    // Si no se especifica tipo, elige uno al azar.
    if (tipo == 0){
        this->tipo = std::rand() % variedad + 1;
    } else{
        this->tipo = tipo;
    }

    // Base de la potencia.
    int base = std::rand() % 10 + 2;
    // Exponente de la potencia.
    int exponente = std::rand() % 5 + 2;

    switch (this->tipo)
    {
    case 1:
        enunciado = "¿Cuánto es " + std::to_string(base) + " elevado a " + std::to_string(exponente) + "?";
        soluciones->push_back(std::to_string((int)std::pow(base, exponente)));
        break;
    }
}
