#include "ejercicios.h"
#include <cmath>
#include <ctime>
#include <iomanip>
#include <sstream>

ejercicioPorcentaje::ejercicioPorcentaje(int tipo){
    variedad = 6;
    std::srand(static_cast<unsigned int>(std::time(nullptr)));

    if (tipo == 0){
        this->tipo = std::rand() % variedad + 1;
    } else{
        this->tipo = tipo;
    }

    switch (this->tipo)
    {
    case 1: // ¿Cuánto es el x% de y?
    {
        int numero = std::rand() % 999 + 1;
        int p_porcentual = std::rand() % 99 + 1;
        double resultado = (numero * p_porcentual) / 100.0;

        enunciado = "¿Cuánto es el " + std::to_string(p_porcentual) + "% de " + std::to_string(numero) + "?";

        if (resultado == (int)resultado) {
            soluciones->push_back(std::to_string((int)resultado));
        } else {
            std::ostringstream oss;
            oss << std::fixed << std::setprecision(2) << resultado;
            soluciones->push_back(oss.str());
        }
        break;
    }

    case 2: // ¿Qué porcentaje es x respecto a y?
    {
        int numero = std::rand() % 200 + 50;
        int p_porcentual = std::rand() % 99 + 1;
        int p_numerico = (numero * p_porcentual) / 100;

        enunciado = "¿Qué porcentaje es " + std::to_string(p_numerico) + " respecto a " + std::to_string(numero) + "?";
        soluciones->push_back(std::to_string(p_porcentual) + "%");
        break;
    }

    case 3: // Si x es el y% de un número, ¿cuál es el número?
    {
        int numero = std::rand() % 500 + 100;
        int p_porcentual = std::rand() % 99 + 1;
        int p_numerico = (numero * p_porcentual) / 100;

        enunciado = "Si " + std::to_string(p_numerico) + " es el " + std::to_string(p_porcentual) + "% de un número, ¿cuál es el número?";
        soluciones->push_back(std::to_string(numero));
        break;
    }

    case 4: // Aumento porcentual
    {
        int precio_original = (std::rand() % 500 + 100) * 10; // Múltiplos de 10
        int aumento_porcentual = std::rand() % 50 + 10;
        int precio_final = precio_original + (precio_original * aumento_porcentual / 100);

        enunciado = "Un producto cuesta $" + std::to_string(precio_original) + ". Si aumenta un " + std::to_string(aumento_porcentual) + "%, ¿cuál será el nuevo precio?";
        soluciones->push_back("$" + std::to_string(precio_final));
        break;
    }

    case 5: // Descuento porcentual
    {
        int precio_original = (std::rand() % 500 + 200) * 10;
        int descuento_porcentual = std::rand() % 30 + 10;
        int precio_final = precio_original - (precio_original * descuento_porcentual / 100);

        enunciado = "Un artículo cuesta $" + std::to_string(precio_original) + ". Si tiene un descuento del " + std::to_string(descuento_porcentual) + "%, ¿cuál será el precio final?";
        soluciones->push_back("$" + std::to_string(precio_final));
        break;
    }

    case 6: // Interés simple
    {
        int capital = (std::rand() % 50 + 10) * 1000;
        int tasa = std::rand() % 10 + 5;
        int tiempo = std::rand() % 5 + 1;
        int interes = (capital * tasa * tiempo) / 100;

        enunciado = "¿Cuál es el interés simple de $" + std::to_string(capital) + " al " + std::to_string(tasa) + "% anual durante " + std::to_string(tiempo) + " año(s)?";
        soluciones->push_back("$" + std::to_string(interes));
        break;
    }
    }
}
