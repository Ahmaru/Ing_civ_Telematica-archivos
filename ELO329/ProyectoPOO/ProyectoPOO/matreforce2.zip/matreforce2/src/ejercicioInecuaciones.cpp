#include "ejercicios.h"
#include <cmath>
#include <ctime>

ejercicioInecuaciones::ejercicioInecuaciones(int tipo){
    variedad = 5;
    std::srand(static_cast<unsigned int>(std::time(nullptr)));

    if (tipo == 0){
        this->tipo = std::rand() % variedad + 1;
    } else{
        this->tipo = tipo;
    }

    switch (this->tipo)
    {
    case 1: //inecuaciones lineales
    {
        int a = std::rand() % 10 + 1;
        int b = std::rand() % 20 - 10;
        int c = std::rand() % 30 - 15;

        bool mayor = std::rand() % 2;
        std::string signo = mayor ? ">" : "<";

        std::string termino_b = "";
        if (b > 0) termino_b = " + " + std::to_string(b);
        else if (b < 0) termino_b = " - " + std::to_string(abs(b));

        enunciado = "Resuelve: " + std::to_string(a) + "x" + termino_b + " " + signo + " " + std::to_string(c);


        double resultado = (double)(c - b) / a;


        if (resultado == (int)resultado) {
            if (mayor) {
                soluciones->push_back("x > " + std::to_string((int)resultado));
            } else {
                soluciones->push_back("x < " + std::to_string((int)resultado));
            }
        } else {
            if (mayor) {
                soluciones->push_back("x > " + formatearFraccion((int)(c - b), a));
            } else {
                soluciones->push_back("x < " + formatearFraccion((int)(c - b), a));
            }
        }
        break;
    }

    case 2: //inecuaciones cuadraticas
    {
        int a = std::rand() % 3 + 1;
        int b = std::rand() % 10 - 5;
        int c = std::rand() % 10 - 5;

        enunciado = "Resuelve: " + std::to_string(a) + "x² ";
        if (b > 0) enunciado += "+ " + std::to_string(b) + "x ";
        else if (b < 0) enunciado += "- " + std::to_string(abs(b)) + "x ";

        if (c > 0) enunciado += "+ " + std::to_string(c) + " > 0";
        else if (c < 0) enunciado += "- " + std::to_string(abs(c)) + " > 0";
        else enunciado += "> 0";

        soluciones->push_back("Usar discriminante y analizar signos");
        break;
    }

    case 3: //inecuaciones con valor absoluto
    {
        int a = std::rand() % 10 + 1;
        int b = std::rand() % 20 + 1;

        bool mayor = std::rand() % 2;
        std::string signo = mayor ? ">" : "<";

        enunciado = "|x - " + std::to_string(a) + "| " + signo + " " + std::to_string(b);

        if (mayor) {
            soluciones->push_back("x < " + std::to_string(a - b) + " o x > " + std::to_string(a + b));
        } else {
            soluciones->push_back(std::to_string(a - b) + " < x < " + std::to_string(a + b));
        }
        break;
    }

    case 4: //inecuaciones con fraccion
    {
        int num = std::rand() % 10 + 1;
        int den = std::rand() % 10 + 2;
        int k = std::rand() % 20 + 1;

        enunciado = "Resuelve: " + std::to_string(num) + "/(x + " + std::to_string(den) + ") > " + std::to_string(k);
        double resultado = (double)(num - k * den) / k;
        if (resultado == (int)resultado) {
            soluciones->push_back("x < " + std::to_string((int)resultado) + " y x ≠ -" + std::to_string(den));
        } else {
            soluciones->push_back("x < " + formatearFraccion(num - k * den, k) + " y x ≠ -" + std::to_string(den));
        }
        break;
    }

    case 5: //sistema de inecuaciones
    {
        int a1 = std::rand() % 5 + 1;
        int b1 = std::rand() % 10 + 1;
        int a2 = std::rand() % 5 + 1;
        int b2 = std::rand() % 10 + 1;

        enunciado = "Resuelve el sistema:\n" +
                    std::to_string(a1) + "x > " + std::to_string(b1) + "\n" +
                    std::to_string(a2) + "x < " + std::to_string(b2);

        double sol1 = (double)b1 / a1;
        double sol2 = (double)b2 / a2;

        if (sol1 < sol2) {
            soluciones->push_back(formatearFraccion(b1, a1) + " < x < " + formatearFraccion(b2, a2));
        } else {
            soluciones->push_back("No hay solución");
        }
        break;
    }
    }
}
