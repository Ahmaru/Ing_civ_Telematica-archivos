#ifndef EJERCICIOS_H
#define EJERCICIOS_H
#include <string>
#include <vector>
#include <cmath>
#include <algorithm>
#include <QObject>

// Forward declarations
namespace Ui { class MainWindow; }
class ejercicio {
public:
    ejercicio(){
        soluciones = new std::vector<std::string>;
    }
    ~ejercicio(){
        delete soluciones;
    }

    std::string getEnunciado(){
        return enunciado;
    }

    std::vector<std::string> * getSoluciones(){
        return soluciones;
    }

protected:
    int variedad;
    int tipo;
    std::string enunciado;
    std::vector<std::string> * soluciones;

    // Función auxiliar para simplificar fracciones
    int mcd(int a, int b) {
        if (b == 0) return a;
        return mcd(b, a % b);
    }

    // Función para formatear fracciones
    std::string formatearFraccion(int numerador, int denominador) {
        if (denominador == 0) return "indefinido";
        if (denominador == 1) return std::to_string(numerador);
        if (numerador == 0) return "0";

        int divisor = mcd(abs(numerador), abs(denominador));
        numerador /= divisor;
        denominador /= divisor;

        if (denominador < 0) {
            numerador = -numerador;
            denominador = -denominador;
        }

        return std::to_string(numerador) + "/" + std::to_string(denominador);
    }
};

// Ejercicios existentes mejorados
class ejercicioPorcentaje : public ejercicio {
public:
    ejercicioPorcentaje(int tipo = 0);
};

class ejercicioPotencia : public ejercicio {
public:
    ejercicioPotencia(int tipo = 0);
};

class ejercicioEcuacion : public ejercicio {
public:
    ejercicioEcuacion(int tipo = 0);
};

class ejercicioFactorizar : public ejercicio{
public:
    ejercicioFactorizar(int tipo = 0);
};

class ejercicioDivisiones : public ejercicio{
public:
    ejercicioDivisiones(int tipo = 0);
};

class ejercicioEcuacionGrafico : public ejercicio{
public:
    ejercicioEcuacionGrafico(int tipo = 0, Ui::MainWindow* ui = nullptr);
    
    
private:
    Ui::MainWindow* m_ui;

    void graficarParabola(int a, int b, int c, Ui::MainWindow* ui = nullptr);
};
//nuevostipos de ejercicios
class ejercicioSistemaEcuaciones : public ejercicio {
public:
    ejercicioSistemaEcuaciones(int tipo = 0);
};

class ejercicioGeometria : public ejercicio {
public:
    ejercicioGeometria(int tipo = 0);
};

class ejercicioLogaritmos : public ejercicio {
public:
    ejercicioLogaritmos(int tipo = 0);
};

class ejercicioTrigonometria : public ejercicio {
public:
    ejercicioTrigonometria(int tipo = 0);
};

class ejercicioDerivadas : public ejercicio {
public:
    ejercicioDerivadas(int tipo = 0);
};

class ejercicioInecuaciones : public ejercicio {
public:
    ejercicioInecuaciones(int tipo = 0);
};

class ejercicioProbabilidad : public ejercicio {
public:
    ejercicioProbabilidad(int tipo = 0);
};

class ejercicioMatrices : public ejercicio {
public:
    ejercicioMatrices(int tipo = 0);
};

#endif // EJERCICIOS_H
