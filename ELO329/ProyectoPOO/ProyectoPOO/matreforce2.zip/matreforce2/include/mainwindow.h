#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "ejercicios.h"
#include <QTimer>
#include <QLabel>
#include <QMovie>
QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    //Universales
    void setSoluciones(ejercicio*);
    void showEnunciado(ejercicio*, QLabel*);
    void IrMenu();
    //Menu
    void IrGenerador();
    void IrDesafio();
    //Generador
    void actualizarTipos();
    void showSolucionGenerador();
    void Generar();
    void genEcuacion(int tipo = 0);
    void genPorcentaje(int tipo = 0);
    void genPotencia(int tipo = 0);
    void genFactorizar(int tipo = 0);
    void genDivisiones(int tipo = 0);
    void genGrafico(int tipo = 0);
    void genSistemaEcuaciones(int tipo = 0);
    void genGeometria(int tipo = 0);
    void genProbabilidad(int tipo = 0);
    void genInecuaciones(int tipo = 0);
    void genLogaritmos(int tipo = 0);
    void genTrigonometria(int tipo = 0);

    //Desafio
    void InicioDesafio();
    void ActualizarTiempo();
    void ActualizarLabelTiempo();
    void EleccionProblemaAleatorio();
    void VerificarRespuesta();
    void SalirDesafio();
    void ActualizarPuntaje();
    ~MainWindow();
public slots:
    void IniciarTiempoDesafio();


private:
    int EjerciciosResueltosDesafio;
    int Puntaje;
    int MultiplicadorPuntaje;
    QStringList listaEjercicios;
    short int ContadorSoluciones;
    int ElecccionProblema;
    int tiempoRestante;
    bool EnDesafio = false;
    bool EnunciadoPuesto;
    QTimer *TiempoDesafioNumero;
    QMovie *movie;
    Ui::MainWindow *ui;
    std::vector<QString> soluciones;
};
#endif // MAINWINDOW_H
